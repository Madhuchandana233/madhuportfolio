import { validationResult } from 'express-validator';
import Contact from '../models/Contact.js';
import { sendEmail } from '../utils/email.js';

export const submitContact = async (req, res) => {
  try {
    // Validate input
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false,
        errors: errors.array() 
      });
    }

    const { name, email, message } = req.body;

    // Save to database
    const contact = new Contact({ name, email, message });
    await contact.save();

    // Send confirmation emails
    try {
      // Send confirmation to user
      await sendEmail({
        to: email,
        subject: 'Thank you for contacting me',
        text: `Hi ${name},\n\nThank you for reaching out. I'll get back to you as soon as possible.\n\nBest regards,\nMadhu Chandana`
      });

      // Send notification to admin
      await sendEmail({
        to: process.env.SMTP_USER,
        subject: 'New Contact Form Submission',
        text: `New message from ${name} (${email}):\n\n${message}`
      });

      res.status(201).json({ 
        success: true,
        message: 'Message sent successfully' 
      });
    } catch (emailError) {
      console.error('Email sending failed:', emailError);
      // Still return success since we saved to database
      res.status(201).json({ 
        success: true,
        message: 'Message received but email notification failed' 
      });
    }
  } catch (error) {
    console.error('Contact submission failed:', error);
    res.status(500).json({ 
      success: false,
      message: 'Error submitting contact form',
      error: error.message 
    });
  }
};