import React, { useState } from 'react';
import { ArrowRight, Download } from 'lucide-react';

const Hero = () => {
  const [imageError, setImageError] = useState(false);

  return (
    <section id="home" className="pt-24 pb-16 min-h-screen flex items-center">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1 text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
              Hi, I'm Madhu Chandana
              <span className="block text-blue-600 mt-2">Full Stack Developer</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-2xl mx-auto lg:mx-0">
              I craft end-to-end web solutions, from beautiful frontends to robust backends. 
              Specializing in modern web technologies and full-stack development.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a
                href="#projects"
                className="bg-blue-600 text-white px-6 py-3 rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors"
              >
                View Projects
                <ArrowRight className="ml-2 w-5 h-5" />
              </a>
              <a
                href="/resume.pdf"
                className="border-2 border-gray-800 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-800 hover:text-white transition-colors flex items-center justify-center"
              >
                Download CV
                <Download className="ml-2 w-5 h-5" />
              </a>
            </div>
          </div>

          <div className="order-1 lg:order-2 relative max-w-md mx-auto">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl bg-gray-100 relative z-10">
              {!imageError ? (
                <img
                  src="https://res.cloudinary.com/dfxpzcm2l/image/upload/v1733592953/msscq1c7jobozd7ubk7i.jpg"
                  alt="Madhu Chandana - Full Stack Developer"
                  className="w-full h-full object-cover"
                  onError={() => setImageError(true)}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-500">
                  <p>Image not available</p>
                </div>
              )}
            </div>
            <div className="absolute -bottom-4 -right-4 w-24 h-24 md:w-32 md:h-32 bg-blue-600 rounded-full -z-10"></div>
            <div className="absolute -top-4 -left-4 w-24 h-24 md:w-32 md:h-32 bg-gray-200 rounded-full -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;