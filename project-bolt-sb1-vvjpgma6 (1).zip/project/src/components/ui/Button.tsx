import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ButtonProps {
  href?: string;
  onClick?: () => void;
  variant?: 'primary' | 'secondary';
  children: React.ReactNode;
  icon?: LucideIcon;
  className?: string;
}

const Button = ({ 
  href, 
  onClick, 
  variant = 'primary', 
  children, 
  icon: Icon,
  className = '' 
}: ButtonProps) => {
  const baseStyles = "px-6 py-3 rounded-lg flex items-center justify-center transition-colors";
  const variants = {
    primary: "bg-blue-600 text-white hover:bg-blue-700",
    secondary: "border-2 border-gray-800 text-gray-800 hover:bg-gray-800 hover:text-white"
  };

  const buttonContent = (
    <>
      {children}
      {Icon && <Icon className="ml-2 w-5 h-5" />}
    </>
  );

  if (href) {
    return (
      <a href={href} className={`${baseStyles} ${variants[variant]} ${className}`}>
        {buttonContent}
      </a>
    );
  }

  return (
    <button 
      onClick={onClick} 
      className={`${baseStyles} ${variants[variant]} ${className}`}
    >
      {buttonContent}
    </button>
  );
};

export default Button;