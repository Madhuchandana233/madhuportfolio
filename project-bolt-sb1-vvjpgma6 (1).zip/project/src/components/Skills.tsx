import React from 'react';
import { Code, Database, Wrench, Users, Brain } from 'lucide-react';

const skillsData = {
  'Frontend Development': {
    icon: Code,
    skills: ['React', 'TypeScript', 'HTML5/CSS', 'JavaScript', 'Responsive Design']
  },
  'Backend Development': {
    icon: Database,
    skills: ['Python', 'Flask', 'SQLite', 'RESTful APIs', 'Database Design']
  },
  'Development Tools': {
    icon: Wrench,
    skills: ['Git', 'VS Code', 'PyCharm', 'npm', 'Webpack']
  },
  'Soft Skills': {
    icon: Users,
    skills: ['Problem Solving', 'Team Collaboration', 'Communication', 'Time Management']
  }
};

const SkillCard = ({ title, skills, Icon }) => (
  <div className="bg-white p-6 rounded-xl shadow-lg transform hover:-translate-y-1 transition-all duration-300">
    <div className="flex items-center mb-4">
      <div className="p-2 bg-blue-100 rounded-lg">
        <Icon className="w-6 h-6 text-blue-600" />
      </div>
      <h3 className="text-xl font-bold ml-3 text-gray-900">{title}</h3>
    </div>
    <ul className="space-y-2">
      {skills.map((skill, index) => (
        <li 
          key={index} 
          className="flex items-center text-gray-700 animate-fade-in"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
          {skill}
        </li>
      ))}
    </ul>
  </div>
);

const Skills = () => {
  return (
    <section id="skills" className="py-16">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-4">Skills & Expertise</h2>
        <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">
          A comprehensive overview of my technical skills, focusing on both frontend development and Python programming.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {Object.entries(skillsData).map(([title, { icon: Icon, skills }], index) => (
            <div 
              key={title}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <SkillCard title={title} skills={skills} Icon={Icon} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;