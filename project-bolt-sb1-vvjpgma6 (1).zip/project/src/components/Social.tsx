import React from 'react';
import { SOCIAL_LINKS } from '../utils/constants';

const Social = () => {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">Let's Connect</h2>
        <div className="flex flex-wrap justify-center gap-6">
          {SOCIAL_LINKS.map(({ name, icon: Icon, url, color }) => (
            <a
              key={name}
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className={`flex items-center gap-2 px-6 py-3 rounded-lg bg-white shadow-md transition-all duration-300 hover:-translate-y-1 ${color}`}
            >
              <Icon className="w-5 h-5" />
              <span>{name}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Social;