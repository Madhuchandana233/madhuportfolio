import React from 'react';
import { Github, Linkedin, Mail, Heart } from 'lucide-react';

const socialLinks = [
  { href: "https://github.com", icon: Github, label: "GitHub" },
  { href: "www.linkedin.com/in/madhu-chandana-52862a23b", icon: Linkedin, label: "LinkedIn" },
  { href: "mailto:g.madhu2309@gmail.com", icon: Mail, label: "Email" }
];

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">Madhu Chandana</h2>
            <p className="text-gray-400 max-w-md">
              Full Stack developer passionate about creating comprehensive web solutions.
              Always learning and growing in the ever-evolving world of web development.
            </p>
          </div>
          <div className="md:text-right">
            <h3 className="text-lg font-semibold mb-4">Connect With Me</h3>
            <div className="flex space-x-6 md:justify-end">
              {socialLinks.map(({ href, icon: Icon, label }) => (
                <a
                  key={label}
                  href={href}
                  className="hover:text-blue-400 transition-colors"
                  aria-label={label}
                >
                  <Icon className="w-6 h-6" />
                </a>
              ))}
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {currentYear} Madhu Chandana. All rights reserved.
            </p>
            <p className="text-gray-400 text-sm flex items-center">
              Made with <Heart className="w-4 h-4 mx-1 text-red-500" /> using React & Tailwind CSS
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;