import React from 'react';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: 'E-Commerce Platform',
    description: 'A full-featured online shopping platform built with React and Node.js',
    image: 'https://images.unsplash.com/photo-1557821552-17105176677c',
    tech: ['React', 'Node.js', 'MongoDB', 'Tailwind CSS'],
    github: 'https://github.com',
    live: 'https://example.com'
  },
  {
    title: 'Task Management App',
    description: 'A collaborative task management tool with real-time updates',
    image: 'https://images.unsplash.com/photo-1540350394557-8d14678e7f91',
    tech: ['React', 'Firebase', 'Material-UI'],
    github: 'https://github.com',
    live: 'https://example.com'
  },
  {
    title: 'Weather Dashboard',
    description: 'Real-time weather tracking with detailed forecasts',
    image: 'https://images.unsplash.com/photo-1592210454359-9043f067919b',
    tech: ['React', 'OpenWeather API', 'ChartJS'],
    github: 'https://github.com',
    live: 'https://example.com'
  }
];

const ProjectCard = ({ project }) => (
  <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-transform hover:-translate-y-1">
    <div className="relative">
      <img
        src={project.image}
        alt={project.title}
        className="w-full h-48 object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 hover:opacity-100 transition-opacity">
        <div className="absolute bottom-4 left-4 right-4 flex justify-end space-x-4">
          <a
            href={project.github}
            className="p-2 bg-white/90 rounded-full text-gray-900 hover:bg-white transition-colors"
            aria-label="View Code"
          >
            <Github className="w-5 h-5" />
          </a>
          <a
            href={project.live}
            className="p-2 bg-white/90 rounded-full text-gray-900 hover:bg-white transition-colors"
            aria-label="Live Demo"
          >
            <ExternalLink className="w-5 h-5" />
          </a>
        </div>
      </div>
    </div>
    <div className="p-6">
      <h3 className="text-xl font-bold mb-2">{project.title}</h3>
      <p className="text-gray-600 mb-4">{project.description}</p>
      <div className="flex flex-wrap gap-2">
        {project.tech.map((tech, i) => (
          <span
            key={i}
            className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm"
          >
            {tech}
          </span>
        ))}
      </div>
    </div>
  </div>
);

const Projects = () => {
  return (
    <section id="projects" className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-4">Featured Projects</h2>
        <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">
          Here are some of my recent projects that showcase my skills and experience in web development.
        </p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;