import { Github, Linkedin, Twitter, Youtube, Instagram, Mail, Phone, MapPin } from 'lucide-react';

export const SOCIAL_LINKS = [
  {
    name: 'GitHub',
    icon: Github,
    url: 'https://github.com/yourusername',
    color: 'hover:text-gray-900'
  },
  {
    name: 'LinkedIn',
    icon: Linkedin,
    url: 'https://linkedin.com/in/yourusername',
    color: 'hover:text-blue-700'
  },
  {
    name: 'Twitter',
    icon: Twitter,
    url: 'https://twitter.com/yourusername',
    color: 'hover:text-blue-400'
  },
  {
    name: 'YouTube',
    icon: Youtube,
    url: 'https://youtube.com/@yourusername',
    color: 'hover:text-red-600'
  },
  {
    name: 'Instagram',
    icon: Instagram,
    url: 'https://instagram.com/yourusername',
    color: 'hover:text-pink-600'
  }
];

export const CONTACT_INFO = [
  {
    icon: Mail,
    label: 'Email',
    value: 'g.madhu2309@gmail.com',
    href: 'mailto:g.madhu2309@gmail.com'
  },
  {
    icon: Phone,
    label: 'Phone',
    value: '+918977340518',
    href: 'tel:+918977340518'
  },
  {
    icon: MapPin,
    label: 'Location',
    value: 'Hyderabad, Telangana, India',
    href: null
  }
];

export const BLOG_POSTS = [
  {
    title: 'My Journey as a Full Stack Developer',
    excerpt: 'Sharing my experiences, challenges, and lessons learned throughout my development career.',
    date: '2024-03-15',
    readTime: '5 min read',
    image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6',
    slug: 'journey-full-stack-developer'
  }
];